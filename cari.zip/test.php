<?php include 'header.php'; ?>


<style>
 

 
</style>

<div class="main-page-wrapper bg-gray">

    <div class="container">

        <div class="page-content card">

            <h4>Simplest init</h4>

            <div class="rescalendar-calendar-wrapper">
                <div class="rescalendar" id="my_calendar_simple"></div>
            </div>


        </div><!-- page-content -->
    </div><!-- container -->
</div><!-- main-page-wrapper -->

<?php include 'footer.php'; ?>